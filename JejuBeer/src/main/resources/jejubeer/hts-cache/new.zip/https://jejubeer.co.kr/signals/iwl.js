<!DOCTYPE html>
<html>
<head>
	<meta charset=utf-8>
	<meta name=viewport content="initial-scale=1, minimum-scale=1, width=device-width">
	<title>Error 404 (Not Found)</title>

	<style>
		* {
			margin: 0;
			padding: 0;
		}
		html {
			background: #F6F6F8;
		}
		body {
			margin: 10% auto 0;
			padding: 30px 0 85px;
			background: url("//static.imweb.me/vendor/images/site/error_404.png") 100% 5px no-repeat;
			background-size: 399px;
			line-height: 1.429;
			max-width: 420px;
			min-height: 180px;
			padding-right: 430px;
		}
		h1 {
			font-weight: 900;
			font-size: 85px;
			color: #00B8FF;
			margin-top: 0.3em;
			margin-bottom: -20px;
		}
		h2 {
			font-size: 34px;
			color: #00B8FF;
			margin: 0 0 1.3em;
			font-weight: normal;
		}
		.error_img {
			width: 507px;
			max-width: 100%;
			margin-bottom: 10px;
		}
		p {
			font-size: 15px;
			color: #7F8A98;
			margin: 0 0 3px;
		}
		.ko {
			font-size: 13px;
		}
		.link {
			margin-top: 20px;
		}
		a {
			color: #00B8FF;
			text-decoration: none;
		}
		@media (max-width: 992px) {
			body {
				margin: 5% auto 0;
				background-size: 40%;
				padding: 30px 460px 85px 15px;
				background-position: 90% 65px;
				max-width: 300px;
			}
		}
		@media (max-width: 767px) {
			body {
				margin: 5% auto 0;
				background-size: 280px;
				padding: 30px 15px 365px;
				background-position: center 290px;
				max-width: 360px;
				text-align: center;
			}
			h1 {
				font-size: 48px;
				margin-bottom: -10px;
			}
			h2 {
				font-size: 24px;
				margin: 0 0 0.75em;
			}
		}
		@media (max-width: 360px) {
			body {
				padding: 15px 15px 300px;
				background-position: center 230px;
			}
			p, p.ko {
				font-size: 12px;
			}
		}
	</style>
</head>
<body>
<h1>404</h1>
<h2>Page Not Found</h2>
<div>
	<p>The page you visited has an invalid or deleted address.(C)</p>
	<p class="ko">방문하신 페이지의 주소가 잘못되었거나 삭제된 페이지입니다.</p>
	<p class="link"><a href="/">홈으로 돌아가기</a></p>
</div>
</body>
</html>
